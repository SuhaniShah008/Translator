public class translator{







	
}